require('dotenv').config();
const express = require('express');
const http = require('http');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const multer = require('multer');
const Database = require('better-sqlite3');
const { Server } = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = new Server(server);
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'dev-only-change-this-secret';
const ADMIN_KEY = process.env.ADMIN_KEY || 'CAMBIAME-ANTES-DE-PUBLICAR';
const db = new Database('app.db');
db.pragma('journal_mode = WAL');
db.exec(`
CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, username TEXT UNIQUE NOT NULL, email TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS packs (id INTEGER PRIMARY KEY, name TEXT NOT NULL, description TEXT DEFAULT '', published INTEGER DEFAULT 1, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS characters (id INTEGER PRIMARY KEY, pack_id INTEGER NOT NULL, name TEXT NOT NULL, image_url TEXT NOT NULL, traits TEXT DEFAULT '{}', FOREIGN KEY(pack_id) REFERENCES packs(id) ON DELETE CASCADE);
`);
const packCount = db.prepare('SELECT COUNT(*) n FROM packs').get().n;
if (!packCount) {
  const p = db.prepare('INSERT INTO packs (name, description) VALUES (?, ?)').run('Futbolistas', 'Pack de ejemplo: agregá tus propios jugadores desde el panel de administrador.');
  const addDemo = db.prepare('INSERT INTO characters (pack_id,name,image_url,traits) VALUES (?,?,?,?)');
  addDemo.run(p.lastInsertRowid, 'Ejemplo: Personaje A', 'https://placehold.co/400x400/172554/ffffff?text=Personaje+A', JSON.stringify({barba:true, pelo:'oscuro', anteojos:false}));
  addDemo.run(p.lastInsertRowid, 'Ejemplo: Personaje B', 'https://placehold.co/400x400/334155/ffffff?text=Personaje+B', JSON.stringify({barba:false, pelo:'claro', anteojos:true}));
}
app.use(express.json({limit:'2mb'}));
app.use(express.static(path.join(__dirname, 'public')));
app.use('/uploads', express.static(path.join(__dirname, 'public/uploads')));
const uploadDir = path.join(__dirname, 'public/uploads');
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, {recursive:true});
const storage = multer.diskStorage({ destination: uploadDir, filename: (req,file,cb) => cb(null, crypto.randomBytes(12).toString('hex') + path.extname(file.originalname).toLowerCase()) });
const upload = multer({storage, limits:{fileSize:5*1024*1024}, fileFilter:(req,file,cb)=> cb(null, /^image\/(jpeg|png|webp|gif)$/.test(file.mimetype))});
function makeToken(payload) { return jwt.sign(payload, JWT_SECRET, {expiresIn:'7d'}); }
function auth(req,res,next) {
  const raw = (req.headers.authorization || '').replace(/^Bearer\s+/i,'');
  try { req.actor = jwt.verify(raw, JWT_SECRET); next(); }
  catch { res.status(401).json({error:'Iniciá sesión para continuar.'}); }
}
function admin(req,res,next) { if (req.actor && req.actor.role === 'admin') return next(); return res.status(403).json({error:'Solo el administrador puede hacer eso.'}); }
app.post('/api/register', async (req,res)=>{
  const {username,email,password} = req.body || {};
  if (!username || !email || !password || String(username).trim().length < 3 || String(password).length < 8) return res.status(400).json({error:'Ingresá usuario (mínimo 3 caracteres), email y contraseña (mínimo 8 caracteres).'});
  try {
    const hash = await bcrypt.hash(String(password), 12);
    const info = db.prepare('INSERT INTO users (username,email,password_hash) VALUES (?,?,?)').run(String(username).trim(),String(email).trim().toLowerCase(),hash);
    const user = {id:Number(info.lastInsertRowid), username:String(username).trim()};
    res.json({token:makeToken({id:user.id,username:user.username,role:'user'}),user});
  } catch(e) { res.status(409).json({error:'Ese usuario o email ya está registrado.'}); }
});
app.post('/api/login', async (req,res)=>{
  const {email,password} = req.body || {};
  const user = db.prepare('SELECT * FROM users WHERE email=?').get(String(email||'').trim().toLowerCase());
  if (!user || !(await bcrypt.compare(String(password||''),user.password_hash))) return res.status(401).json({error:'Email o contraseña incorrectos.'});
  res.json({token:makeToken({id:user.id,username:user.username,role:'user'}),user:{id:user.id,username:user.username}});
});
app.post('/api/admin/login',(req,res)=>{
  if (!process.env.ADMIN_KEY || ADMIN_KEY === 'CAMBIAME-ANTES-DE-PUBLICAR') return res.status(503).json({error:'Configurá ADMIN_KEY en el archivo .env antes de usar el panel privado.'});
  if (!req.body || req.body.key !== ADMIN_KEY) return res.status(401).json({error:'Clave de administrador incorrecta.'});
  res.json({token:makeToken({id:'admin',username:'Administrador',role:'admin'}),user:{username:'Administrador',role:'admin'}});
});
app.get('/api/packs',(req,res)=>{
  const packs = db.prepare('SELECT * FROM packs WHERE published=1 ORDER BY id DESC').all().map(p=>({...p,characters:db.prepare('SELECT id,name,image_url,traits FROM characters WHERE pack_id=? ORDER BY id').all(p.id).map(c=>({...c,traits:JSON.parse(c.traits||'{}')}))}));
  res.json(packs);
});
app.get('/api/admin/packs',auth,admin,(req,res)=>{
  const packs = db.prepare('SELECT * FROM packs ORDER BY id DESC').all().map(p=>({...p,characters:db.prepare('SELECT id,name,image_url,traits FROM characters WHERE pack_id=? ORDER BY id').all(p.id).map(c=>({...c,traits:JSON.parse(c.traits||'{}')}))}));
  res.json(packs);
});
app.post('/api/admin/packs',auth,admin,(req,res)=>{
  const name=String(req.body.name||'').trim(), description=String(req.body.description||'').trim();
  if(name.length<2) return res.status(400).json({error:'El nombre del pack debe tener al menos 2 caracteres.'});
  const r=db.prepare('INSERT INTO packs (name,description,published) VALUES (?,?,?)').run(name,description,req.body.published===false?0:1);
  res.json({id:Number(r.lastInsertRowid),name,description,published:1,characters:[]});
});
app.patch('/api/admin/packs/:id',auth,admin,(req,res)=>{
  const p=db.prepare('SELECT * FROM packs WHERE id=?').get(req.params.id); if(!p)return res.status(404).json({error:'Pack no encontrado.'});
  db.prepare('UPDATE packs SET name=?,description=?,published=? WHERE id=?').run(String(req.body.name??p.name).trim(),String(req.body.description??p.description),req.body.published===undefined?p.published:(req.body.published?1:0),p.id); res.json({ok:true});
});
app.delete('/api/admin/packs/:id',auth,admin,(req,res)=>{ db.prepare('DELETE FROM characters WHERE pack_id=?').run(req.params.id); db.prepare('DELETE FROM packs WHERE id=?').run(req.params.id); res.json({ok:true}); });
app.post('/api/admin/packs/:id/characters',auth,admin,upload.single('image'),(req,res)=>{
  if(!req.file) return res.status(400).json({error:'Subí una imagen JPG, PNG, WEBP o GIF (máximo 5 MB).'});
  const pack=db.prepare('SELECT id FROM packs WHERE id=?').get(req.params.id); if(!pack)return res.status(404).json({error:'Pack no encontrado.'});
  const name=String(req.body.name||'').trim(); if(!name)return res.status(400).json({error:'El personaje necesita un nombre.'});
  let traits={}; try{traits=JSON.parse(req.body.traits||'{}')}catch{}
  const image_url='/uploads/'+req.file.filename;
  const r=db.prepare('INSERT INTO characters (pack_id,name,image_url,traits) VALUES (?,?,?,?)').run(pack.id,name,image_url,JSON.stringify(traits));
  res.json({id:Number(r.lastInsertRowid),pack_id:pack.id,name,image_url,traits});
});
app.delete('/api/admin/characters/:id',auth,admin,(req,res)=>{
  const c=db.prepare('SELECT image_url FROM characters WHERE id=?').get(req.params.id); if(c && c.image_url.startsWith('/uploads/')) { const f=path.join(__dirname,'public',c.image_url); if(fs.existsSync(f))fs.unlinkSync(f); }
  db.prepare('DELETE FROM characters WHERE id=?').run(req.params.id); res.json({ok:true});
});

const rooms = new Map();
function roomCode(){let c; do{c=crypto.randomBytes(3).toString('hex').toUpperCase()}while(rooms.has(c)); return c;}
function publicRoom(room){return {code:room.code,packId:room.packId,packName:room.packName,players:room.players.map(p=>({username:p.username,ready:p.ready,host:p.host})),status:room.status,turn:room.turn,question:room.question,answer:room.answer,winner:room.winner};}
io.use((socket,next)=>{try{const token=socket.handshake.auth?.token; socket.actor=jwt.verify(token,JWT_SECRET); next();}catch{next(new Error('Iniciá sesión para jugar online.'));}});
io.on('connection',socket=>{
  socket.on('room:create',({packId},cb=()=>{})=>{
    const pack=db.prepare('SELECT * FROM packs WHERE id=? AND published=1').get(packId); const chars=pack?db.prepare('SELECT id,name,image_url,traits FROM characters WHERE pack_id=?').all(pack.id):[];
    if(!pack||chars.length<2)return cb({error:'Este pack necesita al menos 2 personajes para jugar.'});
    const code=roomCode(), room={code,packId:pack.id,packName:pack.name,characters:chars.map(c=>({...c,traits:JSON.parse(c.traits||'{}')})),players:[{id:socket.id,userId:socket.actor.id,username:socket.actor.username,host:true,ready:false,secret:null,eliminated:[]}],status:'waiting',turn:0,question:null,answer:null,winner:null};
    rooms.set(code,room); socket.join(code); socket.data.room=code; cb({room:publicRoom(room),characters:room.characters.map(c=>({id:c.id,name:c.name,image_url:c.image_url,traits:c.traits}))}); io.to(code).emit('room:update',publicRoom(room));
  });
  socket.on('room:join',({code},cb=()=>{})=>{
    const room=rooms.get(String(code||'').toUpperCase()); if(!room)return cb({error:'No existe esa sala.'});
    if(room.players.some(p=>p.id===socket.id))return cb({room:publicRoom(room)});
    if(room.players.length>=2)return cb({error:'La sala ya está completa.'}); if(room.status!=='waiting')return cb({error:'La partida ya comenzó.'});
    room.players.push({id:socket.id,userId:socket.actor.id,username:socket.actor.username,host:false,ready:false,secret:null,eliminated:[]}); socket.join(room.code); socket.data.room=room.code;
    cb({room:publicRoom(room),characters:room.characters.map(c=>({id:c.id,name:c.name,image_url:c.image_url,traits:c.traits}))}); io.to(room.code).emit('room:update',publicRoom(room));
  });
  socket.on('game:ready',({characterId},cb=()=>{})=>{
    const room=rooms.get(socket.data.room); if(!room)return cb({error:'No estás en una sala.'}); const p=room.players.find(p=>p.id===socket.id); const c=room.characters.find(c=>c.id===Number(characterId));
    if(!p||!c)return cb({error:'Elegí un personaje válido.'}); p.secret=c.id; p.ready=true;
    if(room.players.length===2&&room.players.every(p=>p.ready)){room.status='playing';room.turn=0;}
    io.to(room.code).emit('room:update',publicRoom(room)); io.to(room.code).emit('game:started',{status:room.status}); cb({ok:true});
  });
  socket.on('game:ask',({question},cb=()=>{})=>{
    const room=rooms.get(socket.data.room); if(!room||room.status!=='playing')return cb({error:'La partida no está en curso.'});
    const idx=room.players.findIndex(p=>p.id===socket.id); if(idx!==room.turn)return cb({error:'Esperá tu turno.'});
    const q=String(question||'').trim().slice(0,180); if(!q)return cb({error:'Escribí una pregunta.'}); room.question=q; room.answer=null;
    io.to(room.code).emit('game:question',{question:q,from:room.players[idx].username}); cb({ok:true});
  });
  socket.on('game:answer',({answer},cb=()=>{})=>{
    const room=rooms.get(socket.data.room); if(!room||!room.question)return cb({error:'No hay pregunta pendiente.'});
    const idx=room.players.findIndex(p=>p.id===socket.id); if(idx===room.turn)return cb({error:'El rival debe responder.'});
    room.answer=answer?'Sí':'No'; room.question=null; room.turn=idx; io.to(room.code).emit('game:answered',{answer:room.answer,by:room.players[idx].username}); io.to(room.code).emit('room:update',publicRoom(room)); cb({ok:true});
  });
  socket.on('game:guess',({characterId},cb=()=>{})=>{
    const room=rooms.get(socket.data.room); if(!room||room.status!=='playing')return cb({error:'La partida no está en curso.'});
    const idx=room.players.findIndex(p=>p.id===socket.id); if(idx!==room.turn)return cb({error:'Esperá tu turno.'});
    const target=room.players[1-idx]; const c=room.characters.find(c=>c.id===Number(characterId)); if(!c)return cb({error:'Personaje inválido.'});
    if(target.secret===c.id){room.status='finished';room.winner=room.players[idx].username;}else{room.turn=1-idx;room.answer='La adivinanza fue incorrecta.';}
    io.to(room.code).emit('game:guess-result',{correct:target.secret===c.id,guess:c.name,winner:room.winner}); io.to(room.code).emit('room:update',publicRoom(room)); cb({ok:true,correct:target.secret===c.id});
  });
  socket.on('disconnect',()=>{const code=socket.data.room; const room=rooms.get(code); if(!room)return; room.players=room.players.filter(p=>p.id!==socket.id); if(room.players.length===0||room.status==='waiting')rooms.delete(code); else {room.status='finished';room.winner=room.players[0]?.username||null;io.to(code).emit('room:update',publicRoom(room));io.to(code).emit('game:opponent-left');}});
});
server.listen(PORT,()=>console.log(`Adivina Quién listo en http://localhost:${PORT}`));
