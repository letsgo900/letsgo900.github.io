# Adivina Quién Online

Primera versión funcional de una web responsive para jugar Adivina Quién online, con cuentas de usuario, salas por código, packs de personajes y un panel privado para subir imágenes.

## Requisitos
- Node.js 18 o superior
- npm

## Ejecutar en tu computadora
1. Descomprimí el proyecto.
2. Copiá `.env.example` como `.env`.
3. Cambiá `JWT_SECRET` por una cadena larga y aleatoria.
4. Cambiá `ADMIN_KEY` por tu clave privada de administrador.
5. En la carpeta del proyecto, ejecutá `npm install`.
6. Ejecutá `npm start`.
7. Abrí `http://localhost:3000`.

La base de datos `app.db` se crea automáticamente. Los retratos que subas quedan en `public/uploads/`.

## Panel de administración
Desde “Administrar packs”, ingresá el valor de `ADMIN_KEY`. Podés crear y publicar/ocultar packs, subir personajes, añadir características y borrar contenido. La clave se valida en el servidor y no está escrita en el JavaScript del navegador.

## Publicar en Internet
Necesitás un hosting que permita ejecutar Node.js, mantener una conexión WebSocket y conservar archivos en disco. Configurá las variables `PORT`, `JWT_SECRET` y `ADMIN_KEY` en el panel del hosting. Si el proveedor usa disco efímero, configurá un volumen persistente para `app.db` y `public/uploads` o migrá la persistencia a una base de datos/almacenamiento administrados.

## Alcance y limitaciones de esta versión
- Las salas online funcionan en tiempo real mediante Socket.IO; una sala admite dos jugadores.
- Los jugadores eligen un personaje secreto y hacen preguntas/respuestas libres de sí/no. La web no verifica automáticamente si una respuesta es honesta.
- La eliminación de personajes es visual y local en cada jugador.
- Las salas viven en memoria del servidor: si se reinicia, las partidas en curso se cierran.
- Las características se guardan como texto/JSON para ayudar a los jugadores, pero no generan preguntas automáticas.
- Es una base inicial, no un servicio auditado para producción. Antes de abrirla públicamente conviene añadir recuperación de contraseña, verificación de email, límites contra abuso y pruebas de seguridad.
